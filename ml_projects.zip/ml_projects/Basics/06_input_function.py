name = input("What's your name? ")
age = input("How old are you? ")
greetings = "Hey,"
print(greetings, name, "You're quite young bro!")