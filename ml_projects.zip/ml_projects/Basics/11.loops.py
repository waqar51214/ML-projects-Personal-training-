# x = 0
# while (x<5):
#     print(x)
#     x = x+1 
    
# for x in range(4,11):
#     print(x)

# array
days = ['Mon','Tues','Wed','Thurs','Fri','sat','sun']
for d in days:
    if (d=='Fri'):continue #skep d 
    print(d)

