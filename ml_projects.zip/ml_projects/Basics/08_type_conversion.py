#implicit conversion
x = 3
y = 3
z = x + y
print(z,type(z))
# explicit conversion
age = input("What is your age? ")
print(age, type(age))