Sayam_Raza = 13
age_for_joining_the_school = 5
if Sayam_Raza == 5:
    print("Sayam should join the school! ")
elif Sayam_Raza < 3:
    print("Sayam is still a baby. Take care of him! ")
elif Sayam_Raza == 4:
    print("He can join the play group classes. ")
elif Sayam_Raza <= 14:
    print("Sayam Raza should join the secondary school. ")
else:
    print("Sayam Raza should join higher school. Good luck!!! ")
