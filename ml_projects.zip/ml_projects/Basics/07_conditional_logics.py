#equals to                         ==
#not equals to                     !=
#greater than and equals to        >=
#less than and equals to           <=
#greater than                      >
#less than                         <
# the conditional logics gives output as "True or False","yes or no" or "0 or 1"
# print(5==6)
# print(4==4)
# print(4<=5)
#Scenario: I want to check whether my nephew's age is ok to go to school.
age_at_school = 5
Sayam_Raza_age = input("What is Sayam's age? ")
print(type(Sayam_Raza_age))
Sayam_Raza_age =int(Sayam_Raza_age)
print(age_at_school == Sayam_Raza_age)