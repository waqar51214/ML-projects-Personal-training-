# varible: Objects containing specific values are called variables in Python
# x = 5 
# print(x)
# x = "My Name isn't given by me!"
# print(x)
# Rules for naming the variables 
#1. Variables should contain numbers, letters and underscores
#2. Variables shouldn't use keywords(break, mean, media, text ec cetra)
#3. case sensitivity(small letters should be used)
#4. short and descriptive
#5. spaces aren't allowed 
#6. Never start variable's name with numbers

fruit_basket = "Mangoes"
fruit_basket = 7
print(fruit_basket)
print(type(fruit_basket))