print('Hello Python!')
print("I'm good!")