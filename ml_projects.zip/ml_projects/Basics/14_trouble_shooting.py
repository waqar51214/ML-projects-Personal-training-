# print(Hello waqar ) # syntax error

# print(25/0) # runtime error i.e mathematical mistake
# # Now the difficult type 
name = 'Waqar'
print('hello name') 
