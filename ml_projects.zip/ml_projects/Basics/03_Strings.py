print(" Hey, what's up ? ")
print('''He said, "I will make it happen by hardwork and devotion!"''')