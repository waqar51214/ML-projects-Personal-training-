#libraries are kind of functions already made by people
import math
print(math.pi)
x = [50, 60, 70, 80]
import statistics
print(statistics.mean(x))


