# def what_to_do():
#     print("Read a book")
#     print("do some programming")
#     print("have some sleep")
# what_to_do()

#second way to use a function
# def what_to_do():
#     text = "work"
#     print(text)
#     print(text)
#     print(text)
# what_to_do()

#third way to use a fcn.
# def what_to_do(text):
#     print(text)
#     print(text)
#     print(text)
#     print(text)
# what_to_do("There are a lot of things to do! ")

#defining a fcn. of future 
def future_age(age):
    new_age = age + 20
    return new_age
    print(new_age)
future_predicted_age =future_age(23)
print(future_predicted_age)

