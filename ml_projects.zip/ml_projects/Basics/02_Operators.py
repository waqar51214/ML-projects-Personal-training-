print(2+6)
print(2**4)
print(9%2)
print(7-1)
print(6//2) #integer division
print(6/2) #floating points result
print(2**3-5//2+1*8) #This expression will be executed as PEMDAS.
#Perenthesis Exponent Multiplication Division Addition Subtraction(PEMDAS)
#The execution will be Left to Right in sequence if M D & A S
print(3//10)