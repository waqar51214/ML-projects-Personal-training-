import seaborn as sns
import matplotlib as plt
sns.set_theme(color_codes = True, style = "ticks")
titanic = sns.load_datasets('titanic')
sns.catplot(x = 'sex', y = 'survived', hue = 'class', kind = 'bar',data = titanic)
titanic.set_title('Visualization')
plt.show()


